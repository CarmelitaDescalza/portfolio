/**
 * Data Transfer Objects.
 */
package com.beroutesjhx.service.dto;
