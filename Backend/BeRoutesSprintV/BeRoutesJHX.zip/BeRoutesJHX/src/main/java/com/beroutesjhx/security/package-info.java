/**
 * Spring Security configuration.
 */
package com.beroutesjhx.security;
