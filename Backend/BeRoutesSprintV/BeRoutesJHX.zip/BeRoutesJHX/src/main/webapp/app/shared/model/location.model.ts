import { Moment } from 'moment';
import { ICountry } from 'app/shared/model/country.model';
import { IPhoto } from 'app/shared/model/photo.model';
import { IQr } from 'app/shared/model/qr.model';
import { ITravelRoute } from 'app/shared/model/travel-route.model';

export interface ILocation {
  id?: number;
  position?: number;
  titleLocation?: string;
  descriptionLocation?: string;
  xCoordinate?: number;
  yCoordinate?: number;
  qrActivation?: boolean;
  qrDescription?: string;
  createdAt?: Moment;
  updatedAt?: Moment;
  country?: ICountry;
  photo?: IPhoto;
  qr?: IQr;
  travelRoute?: ITravelRoute;
}

export class Location implements ILocation {
  constructor(
    public id?: number,
    public position?: number,
    public titleLocation?: string,
    public descriptionLocation?: string,
    public xCoordinate?: number,
    public yCoordinate?: number,
    public qrActivation?: boolean,
    public qrDescription?: string,
    public createdAt?: Moment,
    public updatedAt?: Moment,
    public country?: ICountry,
    public photo?: IPhoto,
    public qr?: IQr,
    public travelRoute?: ITravelRoute
  ) {
    this.qrActivation = this.qrActivation || false;
  }
}
