import { ITravelRoute } from 'app/shared/model/travel-route.model';
import { IUserProfile } from 'app/shared/model/user-profile.model';

export interface IFavorite {
  id?: number;
  jhiLike?: boolean;
  notLike?: boolean;
  travelRoute?: ITravelRoute;
  userProfile?: IUserProfile;
}

export class Favorite implements IFavorite {
  constructor(
    public id?: number,
    public jhiLike?: boolean,
    public notLike?: boolean,
    public travelRoute?: ITravelRoute,
    public userProfile?: IUserProfile
  ) {
    this.jhiLike = this.jhiLike || false;
    this.notLike = this.notLike || false;
  }
}
