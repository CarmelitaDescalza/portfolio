import { Component, OnInit } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { ILocation, Location } from 'app/shared/model/location.model';
import { LocationService } from './location.service';
import { ICountry } from 'app/shared/model/country.model';
import { CountryService } from 'app/entities/country/country.service';
import { IPhoto } from 'app/shared/model/photo.model';
import { PhotoService } from 'app/entities/photo/photo.service';
import { IQr } from 'app/shared/model/qr.model';
import { QrService } from 'app/entities/qr/qr.service';
import { ITravelRoute } from 'app/shared/model/travel-route.model';
import { TravelRouteService } from 'app/entities/travel-route/travel-route.service';

type SelectableEntity = ICountry | IPhoto | IQr | ITravelRoute;

@Component({
  selector: 'jhi-location-update',
  templateUrl: './location-update.component.html',
})
export class LocationUpdateComponent implements OnInit {
  isSaving = false;
  countries: ICountry[] = [];
  photos: IPhoto[] = [];
  qrs: IQr[] = [];
  travelroutes: ITravelRoute[] = [];
  createdAtDp: any;
  updatedAtDp: any;

  editForm = this.fb.group({
    id: [],
    position: [],
    titleLocation: [],
    descriptionLocation: [],
    xCoordinate: [],
    yCoordinate: [],
    qrActivation: [],
    qrDescription: [],
    createdAt: [],
    updatedAt: [],
    country: [],
    photo: [],
    qr: [],
    travelRoute: [],
  });

  constructor(
    protected locationService: LocationService,
    protected countryService: CountryService,
    protected photoService: PhotoService,
    protected qrService: QrService,
    protected travelRouteService: TravelRouteService,
    protected activatedRoute: ActivatedRoute,
    private fb: FormBuilder
  ) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ location }) => {
      this.updateForm(location);

      this.countryService
        .query({ filter: 'location-is-null' })
        .pipe(
          map((res: HttpResponse<ICountry[]>) => {
            return res.body || [];
          })
        )
        .subscribe((resBody: ICountry[]) => {
          if (!location.country || !location.country.id) {
            this.countries = resBody;
          } else {
            this.countryService
              .find(location.country.id)
              .pipe(
                map((subRes: HttpResponse<ICountry>) => {
                  return subRes.body ? [subRes.body].concat(resBody) : resBody;
                })
              )
              .subscribe((concatRes: ICountry[]) => (this.countries = concatRes));
          }
        });

      this.photoService
        .query({ filter: 'location-is-null' })
        .pipe(
          map((res: HttpResponse<IPhoto[]>) => {
            return res.body || [];
          })
        )
        .subscribe((resBody: IPhoto[]) => {
          if (!location.photo || !location.photo.id) {
            this.photos = resBody;
          } else {
            this.photoService
              .find(location.photo.id)
              .pipe(
                map((subRes: HttpResponse<IPhoto>) => {
                  return subRes.body ? [subRes.body].concat(resBody) : resBody;
                })
              )
              .subscribe((concatRes: IPhoto[]) => (this.photos = concatRes));
          }
        });

      this.qrService
        .query({ filter: 'location-is-null' })
        .pipe(
          map((res: HttpResponse<IQr[]>) => {
            return res.body || [];
          })
        )
        .subscribe((resBody: IQr[]) => {
          if (!location.qr || !location.qr.id) {
            this.qrs = resBody;
          } else {
            this.qrService
              .find(location.qr.id)
              .pipe(
                map((subRes: HttpResponse<IQr>) => {
                  return subRes.body ? [subRes.body].concat(resBody) : resBody;
                })
              )
              .subscribe((concatRes: IQr[]) => (this.qrs = concatRes));
          }
        });

      this.travelRouteService.query().subscribe((res: HttpResponse<ITravelRoute[]>) => (this.travelroutes = res.body || []));
    });
  }

  updateForm(location: ILocation): void {
    this.editForm.patchValue({
      id: location.id,
      position: location.position,
      titleLocation: location.titleLocation,
      descriptionLocation: location.descriptionLocation,
      xCoordinate: location.xCoordinate,
      yCoordinate: location.yCoordinate,
      qrActivation: location.qrActivation,
      qrDescription: location.qrDescription,
      createdAt: location.createdAt,
      updatedAt: location.updatedAt,
      country: location.country,
      photo: location.photo,
      qr: location.qr,
      travelRoute: location.travelRoute,
    });
  }

  previousState(): void {
    window.history.back();
  }

  save(): void {
    this.isSaving = true;
    const location = this.createFromForm();
    if (location.id !== undefined) {
      this.subscribeToSaveResponse(this.locationService.update(location));
    } else {
      this.subscribeToSaveResponse(this.locationService.create(location));
    }
  }

  private createFromForm(): ILocation {
    return {
      ...new Location(),
      id: this.editForm.get(['id'])!.value,
      position: this.editForm.get(['position'])!.value,
      titleLocation: this.editForm.get(['titleLocation'])!.value,
      descriptionLocation: this.editForm.get(['descriptionLocation'])!.value,
      xCoordinate: this.editForm.get(['xCoordinate'])!.value,
      yCoordinate: this.editForm.get(['yCoordinate'])!.value,
      qrActivation: this.editForm.get(['qrActivation'])!.value,
      qrDescription: this.editForm.get(['qrDescription'])!.value,
      createdAt: this.editForm.get(['createdAt'])!.value,
      updatedAt: this.editForm.get(['updatedAt'])!.value,
      country: this.editForm.get(['country'])!.value,
      photo: this.editForm.get(['photo'])!.value,
      qr: this.editForm.get(['qr'])!.value,
      travelRoute: this.editForm.get(['travelRoute'])!.value,
    };
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<ILocation>>): void {
    result.subscribe(
      () => this.onSaveSuccess(),
      () => this.onSaveError()
    );
  }

  protected onSaveSuccess(): void {
    this.isSaving = false;
    this.previousState();
  }

  protected onSaveError(): void {
    this.isSaving = false;
  }

  trackById(index: number, item: SelectableEntity): any {
    return item.id;
  }
}
