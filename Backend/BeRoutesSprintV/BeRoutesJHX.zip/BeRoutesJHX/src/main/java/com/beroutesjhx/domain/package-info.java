/**
 * JPA domain objects.
 */
package com.beroutesjhx.domain;
