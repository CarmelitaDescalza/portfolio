/**
 * Spring Data JPA repositories.
 */
package com.beroutesjhx.repository;
