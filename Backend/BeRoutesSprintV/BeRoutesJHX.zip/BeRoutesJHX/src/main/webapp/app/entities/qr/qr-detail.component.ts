import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { IQr } from 'app/shared/model/qr.model';

@Component({
  selector: 'jhi-qr-detail',
  templateUrl: './qr-detail.component.html',
})
export class QrDetailComponent implements OnInit {
  qr: IQr | null = null;

  constructor(protected activatedRoute: ActivatedRoute) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ qr }) => (this.qr = qr));
  }

  previousState(): void {
    window.history.back();
  }
}
