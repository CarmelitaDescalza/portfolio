/**
 * Spring Data Elasticsearch repositories.
 */
package com.beroutesjhx.repository.search;
