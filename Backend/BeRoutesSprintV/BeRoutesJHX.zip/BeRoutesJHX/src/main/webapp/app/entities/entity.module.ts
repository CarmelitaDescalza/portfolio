import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

@NgModule({
  imports: [
    RouterModule.forChild([
      {
        path: 'country',
        loadChildren: () => import('./country/country.module').then(m => m.BeRoutesJhxCountryModule),
      },
      {
        path: 'location',
        loadChildren: () => import('./location/location.module').then(m => m.BeRoutesJhxLocationModule),
      },
      {
        path: 'travel-route',
        loadChildren: () => import('./travel-route/travel-route.module').then(m => m.BeRoutesJhxTravelRouteModule),
      },
      {
        path: 'user-profile',
        loadChildren: () => import('./user-profile/user-profile.module').then(m => m.BeRoutesJhxUserProfileModule),
      },
      {
        path: 'following',
        loadChildren: () => import('./following/following.module').then(m => m.BeRoutesJhxFollowingModule),
      },
      {
        path: 'photo',
        loadChildren: () => import('./photo/photo.module').then(m => m.BeRoutesJhxPhotoModule),
      },
      {
        path: 'valuation',
        loadChildren: () => import('./valuation/valuation.module').then(m => m.BeRoutesJhxValuationModule),
      },
      {
        path: 'qr',
        loadChildren: () => import('./qr/qr.module').then(m => m.BeRoutesJhxQrModule),
      },
      {
        path: 'favorite',
        loadChildren: () => import('./favorite/favorite.module').then(m => m.BeRoutesJhxFavoriteModule),
      },
      /* jhipster-needle-add-entity-route - JHipster will add entity modules routes here */
    ]),
  ],
})
export class BeRoutesJhxEntityModule {}
