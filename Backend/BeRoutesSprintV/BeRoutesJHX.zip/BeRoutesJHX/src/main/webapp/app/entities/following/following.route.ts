import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, Routes, Router } from '@angular/router';
import { JhiResolvePagingParams } from 'ng-jhipster';
import { Observable, of, EMPTY } from 'rxjs';
import { flatMap } from 'rxjs/operators';

import { Authority } from 'app/shared/constants/authority.constants';
import { UserRouteAccessService } from 'app/core/auth/user-route-access-service';
import { IFollowing, Following } from 'app/shared/model/following.model';
import { FollowingService } from './following.service';
import { FollowingComponent } from './following.component';
import { FollowingDetailComponent } from './following-detail.component';
import { FollowingUpdateComponent } from './following-update.component';

@Injectable({ providedIn: 'root' })
export class FollowingResolve implements Resolve<IFollowing> {
  constructor(private service: FollowingService, private router: Router) {}

  resolve(route: ActivatedRouteSnapshot): Observable<IFollowing> | Observable<never> {
    const id = route.params['id'];
    if (id) {
      return this.service.find(id).pipe(
        flatMap((following: HttpResponse<Following>) => {
          if (following.body) {
            return of(following.body);
          } else {
            this.router.navigate(['404']);
            return EMPTY;
          }
        })
      );
    }
    return of(new Following());
  }
}

export const followingRoute: Routes = [
  {
    path: '',
    component: FollowingComponent,
    resolve: {
      pagingParams: JhiResolvePagingParams,
    },
    data: {
      authorities: [Authority.USER],
      defaultSort: 'id,asc',
      pageTitle: 'Followings',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/view',
    component: FollowingDetailComponent,
    resolve: {
      following: FollowingResolve,
    },
    data: {
      authorities: [Authority.USER],
      pageTitle: 'Followings',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'new',
    component: FollowingUpdateComponent,
    resolve: {
      following: FollowingResolve,
    },
    data: {
      authorities: [Authority.USER],
      pageTitle: 'Followings',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/edit',
    component: FollowingUpdateComponent,
    resolve: {
      following: FollowingResolve,
    },
    data: {
      authorities: [Authority.USER],
      pageTitle: 'Followings',
    },
    canActivate: [UserRouteAccessService],
  },
];
