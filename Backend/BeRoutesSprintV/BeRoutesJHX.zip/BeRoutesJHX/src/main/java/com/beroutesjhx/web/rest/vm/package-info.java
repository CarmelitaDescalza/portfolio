/**
 * View Models used by Spring MVC REST controllers.
 */
package com.beroutesjhx.web.rest.vm;
