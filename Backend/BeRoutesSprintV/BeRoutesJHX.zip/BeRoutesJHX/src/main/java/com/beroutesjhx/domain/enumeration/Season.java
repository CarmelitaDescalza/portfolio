package com.beroutesjhx.domain.enumeration;

/**
 * The Season enumeration.
 */
public enum Season {
    SPRING, SUMMER, AUTUMN, WINTER
}
