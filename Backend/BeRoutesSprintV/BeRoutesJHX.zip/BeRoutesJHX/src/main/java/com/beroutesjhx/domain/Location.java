package com.beroutesjhx.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;

import org.springframework.data.elasticsearch.annotations.FieldType;
import java.io.Serializable;
import java.time.LocalDate;

/**
 * A Location.
 */
@Entity
@Table(name = "location")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
@org.springframework.data.elasticsearch.annotations.Document(indexName = "location")
public class Location implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "position")
    private Integer position;

    @Column(name = "title_location")
    private String titleLocation;

    @Column(name = "description_location")
    private String descriptionLocation;

    @Column(name = "x_coordinate")
    private Double xCoordinate;

    @Column(name = "y_coordinate")
    private Double yCoordinate;

    @Column(name = "qr_activation")
    private Boolean qrActivation;

    @Column(name = "qr_description")
    private String qrDescription;

    @Column(name = "created_at")
    private LocalDate createdAt;

    @Column(name = "updated_at")
    private LocalDate updatedAt;

    @OneToOne
    @JoinColumn(unique = true)
    private Country country;

    @OneToOne
    @JoinColumn(unique = true)
    private Photo photo;

    @OneToOne
    @JoinColumn(unique = true)
    private Qr qr;

    @ManyToOne
    @JsonIgnoreProperties(value = "locations", allowSetters = true)
    private TravelRoute travelRoute;

    // jhipster-needle-entity-add-field - JHipster will add fields here
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getPosition() {
        return position;
    }

    public Location position(Integer position) {
        this.position = position;
        return this;
    }

    public void setPosition(Integer position) {
        this.position = position;
    }

    public String getTitleLocation() {
        return titleLocation;
    }

    public Location titleLocation(String titleLocation) {
        this.titleLocation = titleLocation;
        return this;
    }

    public void setTitleLocation(String titleLocation) {
        this.titleLocation = titleLocation;
    }

    public String getDescriptionLocation() {
        return descriptionLocation;
    }

    public Location descriptionLocation(String descriptionLocation) {
        this.descriptionLocation = descriptionLocation;
        return this;
    }

    public void setDescriptionLocation(String descriptionLocation) {
        this.descriptionLocation = descriptionLocation;
    }

    public Double getxCoordinate() {
        return xCoordinate;
    }

    public Location xCoordinate(Double xCoordinate) {
        this.xCoordinate = xCoordinate;
        return this;
    }

    public void setxCoordinate(Double xCoordinate) {
        this.xCoordinate = xCoordinate;
    }

    public Double getyCoordinate() {
        return yCoordinate;
    }

    public Location yCoordinate(Double yCoordinate) {
        this.yCoordinate = yCoordinate;
        return this;
    }

    public void setyCoordinate(Double yCoordinate) {
        this.yCoordinate = yCoordinate;
    }

    public Boolean isQrActivation() {
        return qrActivation;
    }

    public Location qrActivation(Boolean qrActivation) {
        this.qrActivation = qrActivation;
        return this;
    }

    public void setQrActivation(Boolean qrActivation) {
        this.qrActivation = qrActivation;
    }

    public String getQrDescription() {
        return qrDescription;
    }

    public Location qrDescription(String qrDescription) {
        this.qrDescription = qrDescription;
        return this;
    }

    public void setQrDescription(String qrDescription) {
        this.qrDescription = qrDescription;
    }

    public LocalDate getCreatedAt() {
        return createdAt;
    }

    public Location createdAt(LocalDate createdAt) {
        this.createdAt = createdAt;
        return this;
    }

    public void setCreatedAt(LocalDate createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDate getUpdatedAt() {
        return updatedAt;
    }

    public Location updatedAt(LocalDate updatedAt) {
        this.updatedAt = updatedAt;
        return this;
    }

    public void setUpdatedAt(LocalDate updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Country getCountry() {
        return country;
    }

    public Location country(Country country) {
        this.country = country;
        return this;
    }

    public void setCountry(Country country) {
        this.country = country;
    }

    public Photo getPhoto() {
        return photo;
    }

    public Location photo(Photo photo) {
        this.photo = photo;
        return this;
    }

    public void setPhoto(Photo photo) {
        this.photo = photo;
    }

    public Qr getQr() {
        return qr;
    }

    public Location qr(Qr qr) {
        this.qr = qr;
        return this;
    }

    public void setQr(Qr qr) {
        this.qr = qr;
    }

    public TravelRoute getTravelRoute() {
        return travelRoute;
    }

    public Location travelRoute(TravelRoute travelRoute) {
        this.travelRoute = travelRoute;
        return this;
    }

    public void setTravelRoute(TravelRoute travelRoute) {
        this.travelRoute = travelRoute;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Location)) {
            return false;
        }
        return id != null && id.equals(((Location) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "Location{" +
            "id=" + getId() +
            ", position=" + getPosition() +
            ", titleLocation='" + getTitleLocation() + "'" +
            ", descriptionLocation='" + getDescriptionLocation() + "'" +
            ", xCoordinate=" + getxCoordinate() +
            ", yCoordinate=" + getyCoordinate() +
            ", qrActivation='" + isQrActivation() + "'" +
            ", qrDescription='" + getQrDescription() + "'" +
            ", createdAt='" + getCreatedAt() + "'" +
            ", updatedAt='" + getUpdatedAt() + "'" +
            "}";
    }
}
