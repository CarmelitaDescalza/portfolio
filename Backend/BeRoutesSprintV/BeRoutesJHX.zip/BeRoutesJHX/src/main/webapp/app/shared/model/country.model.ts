import { IUserProfile } from 'app/shared/model/user-profile.model';
import { ITravelRoute } from 'app/shared/model/travel-route.model';

export interface ICountry {
  id?: number;
  countryName?: string;
  region?: string;
  city?: string;
  userProfiles?: IUserProfile[];
  travelRoute?: ITravelRoute;
}

export class Country implements ICountry {
  constructor(
    public id?: number,
    public countryName?: string,
    public region?: string,
    public city?: string,
    public userProfiles?: IUserProfile[],
    public travelRoute?: ITravelRoute
  ) {}
}
