import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, Routes, Router } from '@angular/router';
import { JhiResolvePagingParams } from 'ng-jhipster';
import { Observable, of, EMPTY } from 'rxjs';
import { flatMap } from 'rxjs/operators';

import { Authority } from 'app/shared/constants/authority.constants';
import { UserRouteAccessService } from 'app/core/auth/user-route-access-service';
import { IQr, Qr } from 'app/shared/model/qr.model';
import { QrService } from './qr.service';
import { QrComponent } from './qr.component';
import { QrDetailComponent } from './qr-detail.component';
import { QrUpdateComponent } from './qr-update.component';

@Injectable({ providedIn: 'root' })
export class QrResolve implements Resolve<IQr> {
  constructor(private service: QrService, private router: Router) {}

  resolve(route: ActivatedRouteSnapshot): Observable<IQr> | Observable<never> {
    const id = route.params['id'];
    if (id) {
      return this.service.find(id).pipe(
        flatMap((qr: HttpResponse<Qr>) => {
          if (qr.body) {
            return of(qr.body);
          } else {
            this.router.navigate(['404']);
            return EMPTY;
          }
        })
      );
    }
    return of(new Qr());
  }
}

export const qrRoute: Routes = [
  {
    path: '',
    component: QrComponent,
    resolve: {
      pagingParams: JhiResolvePagingParams,
    },
    data: {
      authorities: [Authority.USER],
      defaultSort: 'id,asc',
      pageTitle: 'Qrs',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/view',
    component: QrDetailComponent,
    resolve: {
      qr: QrResolve,
    },
    data: {
      authorities: [Authority.USER],
      pageTitle: 'Qrs',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'new',
    component: QrUpdateComponent,
    resolve: {
      qr: QrResolve,
    },
    data: {
      authorities: [Authority.USER],
      pageTitle: 'Qrs',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/edit',
    component: QrUpdateComponent,
    resolve: {
      qr: QrResolve,
    },
    data: {
      authorities: [Authority.USER],
      pageTitle: 'Qrs',
    },
    canActivate: [UserRouteAccessService],
  },
];
