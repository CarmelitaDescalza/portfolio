import { Component } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { JhiEventManager } from 'ng-jhipster';

import { IFollowing } from 'app/shared/model/following.model';
import { FollowingService } from './following.service';

@Component({
  templateUrl: './following-delete-dialog.component.html',
})
export class FollowingDeleteDialogComponent {
  following?: IFollowing;

  constructor(protected followingService: FollowingService, public activeModal: NgbActiveModal, protected eventManager: JhiEventManager) {}

  cancel(): void {
    this.activeModal.dismiss();
  }

  confirmDelete(id: number): void {
    this.followingService.delete(id).subscribe(() => {
      this.eventManager.broadcast('followingListModification');
      this.activeModal.close();
    });
  }
}
