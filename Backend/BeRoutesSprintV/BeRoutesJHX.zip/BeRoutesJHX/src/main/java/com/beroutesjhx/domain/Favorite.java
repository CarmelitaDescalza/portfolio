package com.beroutesjhx.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;

import org.springframework.data.elasticsearch.annotations.FieldType;
import java.io.Serializable;

/**
 * A Favorite.
 */
@Entity
@Table(name = "favorite")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
@org.springframework.data.elasticsearch.annotations.Document(indexName = "favorite")
public class Favorite implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "jhi_like")
    private Boolean jhiLike;

    @Column(name = "not_like")
    private Boolean notLike;

    @ManyToOne
    @JsonIgnoreProperties(value = "favorites", allowSetters = true)
    private TravelRoute travelRoute;

    @ManyToOne
    @JsonIgnoreProperties(value = "favorites", allowSetters = true)
    private UserProfile userProfile;

    // jhipster-needle-entity-add-field - JHipster will add fields here
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Boolean isJhiLike() {
        return jhiLike;
    }

    public Favorite jhiLike(Boolean jhiLike) {
        this.jhiLike = jhiLike;
        return this;
    }

    public void setJhiLike(Boolean jhiLike) {
        this.jhiLike = jhiLike;
    }

    public Boolean isNotLike() {
        return notLike;
    }

    public Favorite notLike(Boolean notLike) {
        this.notLike = notLike;
        return this;
    }

    public void setNotLike(Boolean notLike) {
        this.notLike = notLike;
    }

    public TravelRoute getTravelRoute() {
        return travelRoute;
    }

    public Favorite travelRoute(TravelRoute travelRoute) {
        this.travelRoute = travelRoute;
        return this;
    }

    public void setTravelRoute(TravelRoute travelRoute) {
        this.travelRoute = travelRoute;
    }

    public UserProfile getUserProfile() {
        return userProfile;
    }

    public Favorite userProfile(UserProfile userProfile) {
        this.userProfile = userProfile;
        return this;
    }

    public void setUserProfile(UserProfile userProfile) {
        this.userProfile = userProfile;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Favorite)) {
            return false;
        }
        return id != null && id.equals(((Favorite) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "Favorite{" +
            "id=" + getId() +
            ", jhiLike='" + isJhiLike() + "'" +
            ", notLike='" + isNotLike() + "'" +
            "}";
    }
}
