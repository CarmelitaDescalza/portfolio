import { Component, OnInit } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';

import { IFollowing, Following } from 'app/shared/model/following.model';
import { FollowingService } from './following.service';
import { IUserProfile } from 'app/shared/model/user-profile.model';
import { UserProfileService } from 'app/entities/user-profile/user-profile.service';

@Component({
  selector: 'jhi-following-update',
  templateUrl: './following-update.component.html',
})
export class FollowingUpdateComponent implements OnInit {
  isSaving = false;
  userprofiles: IUserProfile[] = [];

  editForm = this.fb.group({
    id: [],
    follow: [],
    accepted: [],
    userFollower: [],
    userFollowed: [],
    userProfile: [],
  });

  constructor(
    protected followingService: FollowingService,
    protected userProfileService: UserProfileService,
    protected activatedRoute: ActivatedRoute,
    private fb: FormBuilder
  ) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ following }) => {
      this.updateForm(following);

      this.userProfileService.query().subscribe((res: HttpResponse<IUserProfile[]>) => (this.userprofiles = res.body || []));
    });
  }

  updateForm(following: IFollowing): void {
    this.editForm.patchValue({
      id: following.id,
      follow: following.follow,
      accepted: following.accepted,
      userFollower: following.userFollower,
      userFollowed: following.userFollowed,
      userProfile: following.userProfile,
    });
  }

  previousState(): void {
    window.history.back();
  }

  save(): void {
    this.isSaving = true;
    const following = this.createFromForm();
    if (following.id !== undefined) {
      this.subscribeToSaveResponse(this.followingService.update(following));
    } else {
      this.subscribeToSaveResponse(this.followingService.create(following));
    }
  }

  private createFromForm(): IFollowing {
    return {
      ...new Following(),
      id: this.editForm.get(['id'])!.value,
      follow: this.editForm.get(['follow'])!.value,
      accepted: this.editForm.get(['accepted'])!.value,
      userFollower: this.editForm.get(['userFollower'])!.value,
      userFollowed: this.editForm.get(['userFollowed'])!.value,
      userProfile: this.editForm.get(['userProfile'])!.value,
    };
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<IFollowing>>): void {
    result.subscribe(
      () => this.onSaveSuccess(),
      () => this.onSaveError()
    );
  }

  protected onSaveSuccess(): void {
    this.isSaving = false;
    this.previousState();
  }

  protected onSaveError(): void {
    this.isSaving = false;
  }

  trackById(index: number, item: IUserProfile): any {
    return item.id;
  }
}
