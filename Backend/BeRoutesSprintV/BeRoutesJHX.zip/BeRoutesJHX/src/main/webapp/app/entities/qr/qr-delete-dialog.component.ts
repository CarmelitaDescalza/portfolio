import { Component } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { JhiEventManager } from 'ng-jhipster';

import { IQr } from 'app/shared/model/qr.model';
import { QrService } from './qr.service';

@Component({
  templateUrl: './qr-delete-dialog.component.html',
})
export class QrDeleteDialogComponent {
  qr?: IQr;

  constructor(protected qrService: QrService, public activeModal: NgbActiveModal, protected eventManager: JhiEventManager) {}

  cancel(): void {
    this.activeModal.dismiss();
  }

  confirmDelete(id: number): void {
    this.qrService.delete(id).subscribe(() => {
      this.eventManager.broadcast('qrListModification');
      this.activeModal.close();
    });
  }
}
