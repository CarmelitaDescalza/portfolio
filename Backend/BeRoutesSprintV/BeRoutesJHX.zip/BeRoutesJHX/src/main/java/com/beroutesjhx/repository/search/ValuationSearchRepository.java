package com.beroutesjhx.repository.search;

import com.beroutesjhx.domain.Valuation;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;


/**
 * Spring Data Elasticsearch repository for the {@link Valuation} entity.
 */
public interface ValuationSearchRepository extends ElasticsearchRepository<Valuation, Long> {
}
