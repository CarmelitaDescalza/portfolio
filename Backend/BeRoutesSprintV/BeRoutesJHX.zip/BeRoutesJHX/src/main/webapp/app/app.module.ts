import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import './vendor';
import { BeRoutesJhxSharedModule } from 'app/shared/shared.module';
import { BeRoutesJhxCoreModule } from 'app/core/core.module';
import { BeRoutesJhxAppRoutingModule } from './app-routing.module';
import { BeRoutesJhxHomeModule } from './home/home.module';
import { BeRoutesJhxEntityModule } from './entities/entity.module';
// jhipster-needle-angular-add-module-import JHipster will add new module here
import { MainComponent } from './layouts/main/main.component';
import { NavbarComponent } from './layouts/navbar/navbar.component';
import { FooterComponent } from './layouts/footer/footer.component';
import { PageRibbonComponent } from './layouts/profiles/page-ribbon.component';
import { ErrorComponent } from './layouts/error/error.component';

@NgModule({
  imports: [
    BrowserModule,
    BeRoutesJhxSharedModule,
    BeRoutesJhxCoreModule,
    BeRoutesJhxHomeModule,
    // jhipster-needle-angular-add-module JHipster will add new module here
    BeRoutesJhxEntityModule,
    BeRoutesJhxAppRoutingModule,
  ],
  declarations: [MainComponent, NavbarComponent, ErrorComponent, PageRibbonComponent, FooterComponent],
  bootstrap: [MainComponent],
})
export class BeRoutesJhxAppModule {}
