import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

import { SERVER_API_URL } from 'app/app.constants';
import { createRequestOption, SearchWithPagination } from 'app/shared/util/request-util';
import { IQr } from 'app/shared/model/qr.model';

type EntityResponseType = HttpResponse<IQr>;
type EntityArrayResponseType = HttpResponse<IQr[]>;

@Injectable({ providedIn: 'root' })
export class QrService {
  public resourceUrl = SERVER_API_URL + 'api/qrs';
  public resourceSearchUrl = SERVER_API_URL + 'api/_search/qrs';

  constructor(protected http: HttpClient) {}

  create(qr: IQr): Observable<EntityResponseType> {
    return this.http.post<IQr>(this.resourceUrl, qr, { observe: 'response' });
  }

  update(qr: IQr): Observable<EntityResponseType> {
    return this.http.put<IQr>(this.resourceUrl, qr, { observe: 'response' });
  }

  find(id: number): Observable<EntityResponseType> {
    return this.http.get<IQr>(`${this.resourceUrl}/${id}`, { observe: 'response' });
  }

  query(req?: any): Observable<EntityArrayResponseType> {
    const options = createRequestOption(req);
    return this.http.get<IQr[]>(this.resourceUrl, { params: options, observe: 'response' });
  }

  delete(id: number): Observable<HttpResponse<{}>> {
    return this.http.delete(`${this.resourceUrl}/${id}`, { observe: 'response' });
  }

  search(req: SearchWithPagination): Observable<EntityArrayResponseType> {
    const options = createRequestOption(req);
    return this.http.get<IQr[]>(this.resourceSearchUrl, { params: options, observe: 'response' });
  }
}
