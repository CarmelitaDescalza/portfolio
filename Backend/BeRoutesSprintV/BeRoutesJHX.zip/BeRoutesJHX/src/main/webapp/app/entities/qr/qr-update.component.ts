import { Component, OnInit } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';

import { IQr, Qr } from 'app/shared/model/qr.model';
import { QrService } from './qr.service';
import { ITravelRoute } from 'app/shared/model/travel-route.model';
import { TravelRouteService } from 'app/entities/travel-route/travel-route.service';

@Component({
  selector: 'jhi-qr-update',
  templateUrl: './qr-update.component.html',
})
export class QrUpdateComponent implements OnInit {
  isSaving = false;
  travelroutes: ITravelRoute[] = [];

  editForm = this.fb.group({
    id: [],
    qrDescription: [],
    data1: [],
    data2: [],
    data3: [],
    travelRoute: [],
  });

  constructor(
    protected qrService: QrService,
    protected travelRouteService: TravelRouteService,
    protected activatedRoute: ActivatedRoute,
    private fb: FormBuilder
  ) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ qr }) => {
      this.updateForm(qr);

      this.travelRouteService.query().subscribe((res: HttpResponse<ITravelRoute[]>) => (this.travelroutes = res.body || []));
    });
  }

  updateForm(qr: IQr): void {
    this.editForm.patchValue({
      id: qr.id,
      qrDescription: qr.qrDescription,
      data1: qr.data1,
      data2: qr.data2,
      data3: qr.data3,
      travelRoute: qr.travelRoute,
    });
  }

  previousState(): void {
    window.history.back();
  }

  save(): void {
    this.isSaving = true;
    const qr = this.createFromForm();
    if (qr.id !== undefined) {
      this.subscribeToSaveResponse(this.qrService.update(qr));
    } else {
      this.subscribeToSaveResponse(this.qrService.create(qr));
    }
  }

  private createFromForm(): IQr {
    return {
      ...new Qr(),
      id: this.editForm.get(['id'])!.value,
      qrDescription: this.editForm.get(['qrDescription'])!.value,
      data1: this.editForm.get(['data1'])!.value,
      data2: this.editForm.get(['data2'])!.value,
      data3: this.editForm.get(['data3'])!.value,
      travelRoute: this.editForm.get(['travelRoute'])!.value,
    };
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<IQr>>): void {
    result.subscribe(
      () => this.onSaveSuccess(),
      () => this.onSaveError()
    );
  }

  protected onSaveSuccess(): void {
    this.isSaving = false;
    this.previousState();
  }

  protected onSaveError(): void {
    this.isSaving = false;
  }

  trackById(index: number, item: ITravelRoute): any {
    return item.id;
  }
}
