package com.beroutesjhx.domain;

import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;
import com.beroutesjhx.web.rest.TestUtil;

public class FollowingTest {

    @Test
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(Following.class);
        Following following1 = new Following();
        following1.setId(1L);
        Following following2 = new Following();
        following2.setId(following1.getId());
        assertThat(following1).isEqualTo(following2);
        following2.setId(2L);
        assertThat(following1).isNotEqualTo(following2);
        following1.setId(null);
        assertThat(following1).isNotEqualTo(following2);
    }
}
