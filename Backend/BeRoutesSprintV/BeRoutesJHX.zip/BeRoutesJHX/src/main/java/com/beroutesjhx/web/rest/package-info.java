/**
 * Spring MVC REST controllers.
 */
package com.beroutesjhx.web.rest;
