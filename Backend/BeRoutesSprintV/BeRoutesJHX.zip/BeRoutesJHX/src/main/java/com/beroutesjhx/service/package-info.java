/**
 * Service layer beans.
 */
package com.beroutesjhx.service;
