package com.beroutesjhx.repository.search;

import com.beroutesjhx.domain.TravelRoute;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;


/**
 * Spring Data Elasticsearch repository for the {@link TravelRoute} entity.
 */
public interface TravelRouteSearchRepository extends ElasticsearchRepository<TravelRoute, Long> {
}
